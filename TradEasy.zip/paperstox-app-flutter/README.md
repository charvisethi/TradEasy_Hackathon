# PaperStox

This way you won’t lose c̶o̶n̶f̶i̶d̶e̶n̶c̶e̶ money.

## Project Description

PaperStox is a stock paper-trading application. A paper trade is a simulated trade that allows an investor to practice buying and selling without risking real money. PaperStox allows users to register on the platform and create a fixed budget for themselves, using which they can purchase stocks across US stock exchanges.
