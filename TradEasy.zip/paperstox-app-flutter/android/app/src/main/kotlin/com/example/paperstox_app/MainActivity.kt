package com.example.paperstox_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
