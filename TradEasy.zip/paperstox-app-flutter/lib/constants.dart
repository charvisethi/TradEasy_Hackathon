const baseUrl = 'https://finnhub.io';
const apiKey = 'c6m0etaad3i9dkni2fqg';
