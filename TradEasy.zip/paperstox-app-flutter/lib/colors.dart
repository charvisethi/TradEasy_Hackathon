import 'dart:ui';

const blackPrimary = Color(0xff1e2124);
const greenAccent = Color(0xFF004080);
const greyHint = Color(0xFF808080);
